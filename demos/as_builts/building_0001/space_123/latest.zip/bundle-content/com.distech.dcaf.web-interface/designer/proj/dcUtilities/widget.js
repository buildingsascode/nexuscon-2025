'use strict';

const isEclypse2 = !(dgluxjs && dgluxjs.serverType && dgluxjs.serverType !== 'eclypse2');
const isEclypseUILoadeded = window.EclypseUI && window.EclypseUI.widgets && window.EclypseUI.widgets.DistechControls;

const EmptyWidget = {
  dgNewWidget(div, model) {
    return new dgluxjs.Widget(div, model);
  },
};


const envysionJsLoader = {
  loading: { envysion: [] },
  t: (str, option) => {
    // translate
    const translateFunction = window.DesignerPage.i18n ? window.DesignerPage.i18n.t : window.i18next.t;
    if (translateFunction) {
      return translateFunction(str, option);
    }
    return str;
  },
  updateTheme: (theme) => {
    // update theme provider for dglux
    if (theme !== 'light' && theme !== 'dark') {
      return;
    }
    if (window.DesignerPage && window.DesignerPage.updatePreferences) {
      window.DesignerPage.updatePreferences(
        [{
          "name": "theme",
          "category": "general",
          "type": "select",
          "id": "general-theme",
          "key": "theme",
          "value": theme === 'light' ? 'distechLight' : 'distechDark',
          "isDirty": true
        }]
      );
    }
  },
  loadJs: (url, callback) => {
    const loading = envysionJsLoader.loading[url];
    if (loading === false) {
      // already ready to use
      callback();
      return;
    }
    if (Array.isArray(loading)) {
      // still loading
      loading.push(callback);
      return;
    }
    envysionJsLoader.loading[url] = [callback];
    const script = document.createElement('script');
    script.type = 'module';
    script.src = url;
    script.onload = () => {
      const callbacks = envysionJsLoader.loading[url];
      envysionJsLoader.loading[url] = false;
      for (let i = 0; i < callbacks.length; ++i) {
        callbacks[i]();
      }
    };
    document.body.appendChild(script);
  },

  widgetMap: {},
  widgetsManifest: null,
  loadEnvysionWidget: (widgetId, onWidgetReady) => {
    envysionJsLoader.loadJs('envysion', () => {
      const [componentName, vendor] = widgetId.split('@');
      const metadata = envysionJsLoader.widgetsManifest.find(
        (meta) => meta.vendor === vendor && meta.componentName === componentName
      );
      if (!metadata) {
        onWidgetReady(EmptyWidget);
        return;
      }

      function createReactWidget() {
        // Widget schema can be static or dynamic. If dynamic, we want to refresh the schema.
        const Component =
          window.EclypseUI.widgets[vendor][componentName][componentName];

        if (Component.reactElement && Component.reactElement.getSchema) {
          // getSchema can be the schema object or a promise.
          Promise.resolve(Component.reactElement.getSchema())
            .then((newSchema) => {
              // Update widget schema in the window.
              window.EclypseUI.widgets[vendor][componentName][
                componentName
              ].schema = newSchema;
            })
            .then(() => {
              envysionJsLoader.createReactWidget(
                widgetId,
                metadata,
                onWidgetReady
              );
            });
        } else {
          envysionJsLoader.createReactWidget(widgetId, metadata, onWidgetReady);
        }
      }

      if (
        window.EclypseUI &&
        window.EclypseUI.widgets &&
        window.EclypseUI.widgets[vendor] &&
        window.EclypseUI.widgets[vendor][componentName]
      ) {
        createReactWidget();
      } else {
        window.DesignerPage.importReactWidgetAsync({
          componentName,
          vendor,
          i18nPrefix: `${vendor}##${componentName}`,
        }).then(createReactWidget);
      }
    });
  },
  loadEnvysion: () => {
    let allJsFileLoaded = false;
    const onEnvysionReady = () => {
      allJsFileLoaded = true;
      if (window.envysionInitialTheme) {
        envysionJsLoader.updateTheme(window.envysionInitialTheme);
        window.envysionInitialTheme = null;
      }
      if (envysionJsLoader.widgetsManifest) {
        // all basic dependencies loaded
        const callbacks = envysionJsLoader.loading.envysion;
        envysionJsLoader.loading.envysion = false;
        for (let i = 0; i < callbacks.length; ++i) {
          callbacks[i]();
        }
      }
    };

    function componentsMetaDataLoaded(widgetsManifest) {
      envysionJsLoader.widgetsManifest = widgetsManifest.filter(
        (widget) => widget.designer !== true && widget.componentName !== "DesignerPage"
      );
      if (allJsFileLoaded) {
        onEnvysionReady();
      }
    }

    const checkWidgetPromises = [];
    const widgetsManifest = [];
    for (const widgetName of ['WeatherConditions', 'WidgetAlarms', 'WidgetDataBox', 'WidgetSchedules', 'WidgetTrendBuilder']) {
      checkWidgetPromises.push(fetch(`./web-content/widgets/${widgetName}/manifest.json`)
        .then((result) => result.json())
        .then((result)=>{
          if (!result.error) {
            widgetsManifest.push(result);
          }
        })
        .catch(console.warn)
      );
    }
    Promise.all(checkWidgetPromises).then(()=>{
      componentsMetaDataLoaded(widgetsManifest.sort((a, b) => a.name.en.localeCompare(b.name.en)));
    });


    if (isEclypseUILoadeded) {
      onEnvysionReady();
    } else {
      const libsToLoad = [];

      function loadEnvysionLib(libName) {
        let callback = onEnvysionReady;
        if (libsToLoad.length) {
          const name = libsToLoad.shift();
          callback = () => loadEnvysionLib(name);
        }
        envysionJsLoader.loadJs(`./static/js/${libName}.lib.js`, callback);
      }
      loadEnvysionLib('main');
    }
  },

  createReactWidget: (widgetId, metadata, onWidgetReady) => {
    if (envysionJsLoader.widgetMap.hasOwnProperty(widgetId)) {
      onWidgetReady(envysionJsLoader.widgetMap[widgetId]);
      return;
    }
    const [componentName, vendor] = widgetId.split('@');
    const i18nNS = metadata.namespace || `${vendor}##${componentName}`;
    const Component = window.EclypseUI.widgets[vendor][componentName][componentName];

    const variables = [];
    const variableNames = [];
    const subprops = [];
    const { properties } = Component.schema.schema;
    const uiElements = Component.schema.uiSchema.elements;
    let outputElements = [];
    if (Component.schema.outputSchema) {
      outputElements = Component.schema.outputSchema.elements;
    }
    const nameToOutputProp = {};
    const outputConverters = {};

    const deniedPropList = ['description', 'size', 'title'];
    const serverType = (window.dgluxjs && window.dgluxjs.serverType) || 'eclypse2';
    const addDsaPath = widgetId === 'WidgetSchedules@DistechControls' && serverType === 'dsa';
    if (addDsaPath) {
      uiElements.push({ items: { type: "Control" }, type: 'Control', scope: '#/properties/dsLinkPath' });
    }
    for (const element of uiElements) {
      const name = element.scope.split('/').pop();
      if (deniedPropList.indexOf(name) < 0) {
        const property = properties[name];
        let type = 'string';
        switch (element.type) {
          case 'Hidden': // treat Hidden same as Control
          case 'Control': {
            switch (property.type) {
              case 'string': {
                if (name.endsWith('Url')) {
                  type = 'path';
                } else if (property.format === 'date') {
                  type = 'date';
                } else if (property.enum) {
                  type = 'enum';
                } else if (property.subprops) {
                  type = 'propertymap';
                } else if (property.oneOf) {
                  // special case of enum
                  type = 'enum';
                } else {
                  type = 'string';
                }
                break;
              }
              case 'integer': {
                type = 'number';
                break;
              }
              case 'boolean': {
                type = 'bool';
                break;
              }
              case 'array': {
                // treat array property as propertymap if items have path field
                if (property.items && property.items.properties && property.items.properties.path) {
                  type = 'propertymap';
                } else {
                  type = 'list';
                }
                break;
              }
            }
            break;
          }
          case 'dsapath': {
            type = 'nodepath';
            break;
          }
          case 'daterange': {
            type = 'daterange';
            break;
          }
          case 'url': {
            type = 'path';
            break;
          }
        }

        variables.push({
          t: type,
          n: name,
          nullValue: property.default,
          label: envysionJsLoader.t(property.title, {
            ns: i18nNS,
            defaultValue: name,
          }),
        });

        if (type === 'enum') {
          const lastVariable = variables[variables.length - 1];
          if (property.enum) {
            lastVariable.enums = property.enum;
            if (property.enumLocalized) {
              const enumLabels = [];
              property.enumLocalized.forEach((key, index) => {
                enumLabels.push(
                  envysionJsLoader.t(key, {
                    ns: i18nNS,
                    defaultValue: property.enum[index],
                  })
                );
              });
              lastVariable.enumLabels = enumLabels;
            }
          } else if (property.oneOf) {
            // Special case when enum is defined as oneOf instead of enum
            const enums = [];
            const enumLabels = [];
            property.oneOf.forEach((pair) => {
              enums.push(pair.const);
              enumLabels.push(pair.title);
            });
            lastVariable.enums = enums;
            lastVariable.enumLabels = enumLabels;
          }
          
        } else if (type === 'propertymap') {
          const subpropsList = [];
          const propertySubprops = property.subprops ? property.subprops : property.items.properties;
          Object.keys(propertySubprops).forEach((propName) => {
            // Don't parse path field in propertymap
            if (propName != 'path') {
              const propData = propertySubprops[propName];
              let { type } = propData;
              switch (type) {
                case 'string': {
                  if (propData.enum) {
                    type = 'enum';
                  }
                  break;
                }
                case 'integer': {
                  type = 'number';
                  break;
                }
                case 'boolean': {
                  type = 'bool';
                  break;
                }
                case 'array': {
                  type = 'multiselectEnum';
                  break;
                }
              }
              subpropsList.push({
                n: propName,
                t: type,
                nullValue: propData.default,
                label: envysionJsLoader.t(propData.title, {
                  ns: i18nNS,
                  defaultValue: propName,
                }),
              });
              if (type === 'enum') {
                subpropsList[subpropsList.length - 1].enums = propData.enum;
              }
              const helpTitle = envysionJsLoader.t(propData.helpTitle, {
                ns: i18nNS,
                defaultValue: undefined,
              });
              const helpContent = envysionJsLoader.t(propData.helpContent, {
                ns: i18nNS,
                defaultValue: undefined,
              });
              if (helpTitle && helpContent) {
                subpropsList[subpropsList.length - 1].helpTitle = helpTitle;
                subpropsList[subpropsList.length - 1].helpContent = helpContent;
              }
            }
          });
          subprops.push({ name, subprops: subpropsList });
        }

        const helpTitle = envysionJsLoader.t(property.helpTitle, {
          ns: i18nNS,
          defaultValue: undefined,
        });
        const helpContent = envysionJsLoader.t(property.helpContent, {
          ns: i18nNS,
          defaultValue: undefined,
        });
        if (helpTitle && helpContent) {
          variables[variables.length - 1].helpTitle = helpTitle;
          variables[variables.length - 1].helpContent = helpContent;
        }
        variableNames.push(name);
      }
    }

    for (const element of outputElements) {
      const { name, scope, converter, title } = element;
      let { type } = element;
      switch (type) {
        case 'integer': {
          type = 'number';
          break;
        }
        case 'boolean': {
          type = 'bool';
          break;
        }
      }
      nameToOutputProp[name] = scope;
      if (converter) {
        outputConverters[name] = converter;
      } else {
        outputConverters[name] = (value) => value;
      }

      variables.push({
        t: type,
        n: name,
        label: envysionJsLoader.t(title || `parameters.${name}.label`, {
          ns: i18nNS,
          defaultValue: name,
        }),
      });
      variableNames.push(name);
    }

    const MyWidget = (function (_super) {
      __extends(MyWidget, _super);

      function MyWidget(div, model) {
        _super.call(this, div, model);
        this.contentDiv = document.createElement('div');
        this.contentDiv.className = 'dglux_react_widget';
        div.appendChild(this.contentDiv);

        this.outputCallbacks = {};
        for (const name in outputConverters) {
          const converter = outputConverters[name];
          this.outputCallbacks[name] = (...args) => {
            const value = converter.apply(null, args);
            this.updateModelValue(name, value);
          };
        }
      }
      MyWidget.prototype.getParamValues = function () {
        const result = {};
        for (const name of variableNames) {
          if (this.outputCallbacks.hasOwnProperty(name)) {
            result[nameToOutputProp[name]] = this.outputCallbacks[name];
          } else {
            const value = this.getModelValue(name);
            // passing null value would affect the default parameters defined in the component
            if (value != null) {
              if (properties[name]) {
                if (properties[name].type === 'boolean') {
                  if (value === 'false' || value === 'Inactive') {
                     result[name] = false;
                  } else {
                    result[name] = Boolean(value);
                  }
                  continue;
                } else if (properties[name].type === 'number') {
                  result[name] = parseFloat(value);
                  continue;
                } else if (properties[name].type === 'string' && value != null) {
                  result[name] = String(value);
                  continue;
                } else if (properties[name].type === 'array' && typeof value === 'string' && value[0] === '[') {
                  // decode the array as json
                  result[name] = JSON.parse(value);
                  continue;
                }
              } 
              result[name] = value;
            }
          }
        }
        return result;
      };
      MyWidget.prototype.updateParameters = function (widgetId, parameterPath, parameterId, newValue) {
        // only support top level property, not nested property
        if (parameterPath && variableNames.indexOf(parameterPath) >= 0) {
          if (properties[parameterPath] && properties[parameterPath].type === 'array' && Array.isArray(newValue)) {
            // encode the array as json
            this.setModelValue(parameterPath, JSON.stringify(newValue));
          } else {
            this.setModelValue(parameterPath, newValue);
          }
        }
      }

      MyWidget.prototype.getDefinition = function () {
        // definition of parameters
        // the structure of the json parameter defintion is same as the symbol parameters in dg5
        const layoutChildren = [];
        const subpropsMap = {};
        subprops.forEach((item) => {
          subpropsMap[item.name] = item.subprops;
        });
        variableNames.forEach((name) => {
           if (!properties[name]?.title) {
            // Ignore the property if title is not defined.
            return;
          }
          if (subpropsMap[name]) {
            layoutChildren.push({
              type: 'propertymap',
              children: subpropsMap[name].map((p) => p.n).filter(Boolean),
              label: name,
            });
          } else {
            layoutChildren.push(name);
          }
        });
        return {
          name: '',
          variables,
          layout: {
            type: 'vbox',
            children: layoutChildren, // order of properties
          },
          subprops,
        };
      };

      MyWidget.prototype.commitProperties = function (changes) {
        if (changes) {
          let hasChange = false;
          for (const key of changes) {
            if (
              variableNames.indexOf(key) > -1 &&
              !this.outputCallbacks.hasOwnProperty(key) // ignore output value change
            ) {
              hasChange = true;
              break;
            }
          }
          if (!hasChange) {
            return;
          }
        }
        window.DesignerPage.dgUpdateReactWidget(this.contentDiv, widgetId, this.getParamValues(), (a, b, c, d) => this.updateParameters(a, b, c, d));
      };

      MyWidget.prototype.destroy = function () {
        window.DesignerPage.dgUpdateReactWidget(this.contentDiv, null, {});
        this.contentDiv.remove();
      };

      return MyWidget;
    })(dgluxjs.Widget);

    const module = {
      dgNewWidget(div, model) {
        return new MyWidget(div, model);
      },
    };
    envysionJsLoader.widgetMap[widgetId] = module;
    onWidgetReady(module);
  },
};
envysionJsLoader.loadEnvysion();

dgdefine([], function () {
  return { dgLoadWidget: envysionJsLoader.loadEnvysionWidget };
});

dgluxjs.listReactWidgets = function () {
  if (envysionJsLoader.widgetsManifest) {
    return JSON.stringify(envysionJsLoader.widgetsManifest);
  }
  return 'null';
};
