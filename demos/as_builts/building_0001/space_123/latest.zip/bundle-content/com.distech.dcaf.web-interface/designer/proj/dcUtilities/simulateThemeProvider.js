// code here will only run only once

function simulateThemeProvider() {
  // code here will run once for each block

  function onInvoke(meta, getValue, setValue) {
    // code here will run everytime the block is invoked

    let themeValue = getValue('value') || getValue('invoke');
    if (themeValue === 'dark' || themeValue === 'light') {
      if (window.envysionJsLoader) {
        window.envysionJsLoader.updateTheme(themeValue);
      } else {
        window.envysionInitialTheme = themeValue;
      }
    }
  }
  return onInvoke;
}
